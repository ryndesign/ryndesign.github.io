// Sample puzzles.js
window.LIVE_PUZZLES = [
  { image: "images/1.png", name: "Michael Jackson", hint: "Beat It, Thriller", answers: ["MJ","Jackson"] },
  { image: "images/2.png", name: "Hulk Hogan", hint: "Hulkamania", answers: ["Hogan","The Hulkster"] }
];