// Pixel People Main Logic (shortened)
console.log('Pixel People main.js loaded');